"""
This script runs the application using a development server.
It contains the definition of routes and views for the application.
"""

from flask import Flask
app = Flask(__name__)

# Make the WSGI interface available at the top level so wfastcgi can get it.
wsgi_app = app.wsgi_app


@app.route('/', methods = ['POST,GET'])
def BankManagement():
    if request.method == 'POST':
        BankManagement = request.form
    return render_template('BankManagement.html', name = "Jerry")

@app.route('/loan_pools', methods = ['POST, GET'])
def LoanPools():
    if request.method == 'POST':
        LoanPools = request.form
    return render_template('LoanPools.html', LoanPools = LoanPools)

@app.route('/loan_pools/generated_loan_pools', methods = ['POST, GET'])
def GeneratedLoanPools():
    if request.method == 'POST':
        GeneratedLoanPools = request.form
        return render_template('GeneratedLoanPools.html', GeGeneratedLoanPools = GeneratedLoanPools)


@app.route('/requests', method = ['POST, GET'])
def Requests():
    if request.method == 'POST':
        Requests = request.form
    return render_template('Requests.html', Requests = Requests)


if __name__ == '__main__':
    import os
    HOST = os.environ.get('SERVER_HOST', 'localhost')
    try:
        PORT = int(os.environ.get('SERVER_PORT', '5555'))
    except ValueError:
        PORT = 5555
    app.run(HOST, PORT)
